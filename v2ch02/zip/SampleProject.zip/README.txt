Welcome to Sample Project v1.0
=============================

This project demonstrates how to create a basic file structure
with documentation. To get started:

1. Run `npm install` to setup dependencies
2. Check the docs/ folder for detailed guides
3. Edit config.json before first use
